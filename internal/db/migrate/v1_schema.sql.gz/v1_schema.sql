CREATE TABLE IF NOT EXISTS settings ( domain{V64} PRIMARY KEY, value_json{LTXT} NOT NULL, secret_ciphertext{TXT} NOT NULL, version{BIG} NOT NULL DEFAULT 1, updated_at{BIG} NOT NULL ){SFX}
CREATE TABLE IF NOT EXISTS users ( id{V32} PRIMARY KEY, username{V64} NOT NULL UNIQUE, email{VK} NOT NULL UNIQUE, display_name{V128} NOT NULL, avatar_url{V512} NOT NULL, bio{TXT} NOT NULL, website_url{V512} NOT NULL, role{V32} NOT NULL, password_hash{V255} NOT NULL, legacy_hash{V255} NOT NULL, status{V32} NOT NULL, email_verified_at{BIG} NOT NULL DEFAULT 0, preferred_locale{V32} NOT NULL, created_at{BIG} NOT NULL, updated_at{BIG} NOT NULL ){SFX}
CREATE INDEX idx_users_role_status ON users (role, status)
CREATE TABLE IF NOT EXISTS user_credentials ( id{V32} PRIMARY KEY, user_id{V32} NOT NULL, kind{V32} NOT NULL, name{V128} NOT NULL, credential_id{VLK} NOT NULL DEFAULT '', public_key_spki{TXT} NOT NULL, cose_alg{INT} NOT NULL DEFAULT 0, sign_count{BIG} NOT NULL DEFAULT 0, secret_ciphertext{TXT} NOT NULL, meta_json{TXT} NOT NULL, last_used_at{BIG} NOT NULL DEFAULT 0, created_at{BIG} NOT NULL ){SFX}
CREATE INDEX idx_user_credentials_user_kind ON user_credentials (user_id, kind)
CREATE INDEX idx_user_credentials_cred_id ON user_credentials (credential_id)
CREATE TABLE IF NOT EXISTS user_sessions ( id{V32} PRIMARY KEY, user_id{V32} NOT NULL, token_hash{V64} NOT NULL UNIQUE, ip_masked{V64} NOT NULL, geo_region{V128} NOT NULL, user_agent{V255} NOT NULL, totp_verified_until{BIG} NOT NULL DEFAULT 0, expires_at{BIG} NOT NULL, last_seen_at{BIG} NOT NULL, created_at{BIG} NOT NULL ){SFX}
CREATE INDEX idx_user_sessions_user_exp ON user_sessions (user_id, expires_at)
CREATE TABLE IF NOT EXISTS api_tokens ( id{V32} PRIMARY KEY, user_id{V32} NOT NULL, name{V128} NOT NULL, token_prefix{V32} NOT NULL, token_hash{V64} NOT NULL UNIQUE, scopes_json{TXT} NOT NULL, last_used_at{BIG} NOT NULL DEFAULT 0, expires_at{BIG} NOT NULL DEFAULT 0, created_at{BIG} NOT NULL ){SFX}
CREATE INDEX idx_api_tokens_user ON api_tokens (user_id)
CREATE TABLE IF NOT EXISTS categories ( id{V32} PRIMARY KEY, name{V128} NOT NULL, slug{V128} NOT NULL UNIQUE, description{TXT} NOT NULL, icon{V255} NOT NULL DEFAULT '', sort_order{INT} NOT NULL DEFAULT 0, created_at{BIG} NOT NULL, updated_at{BIG} NOT NULL ){SFX}
CREATE INDEX idx_categories_order ON categories (sort_order)
CREATE TABLE IF NOT EXISTS tags ( id{V32} PRIMARY KEY, name{V128} NOT NULL UNIQUE, slug{V128} NOT NULL UNIQUE, created_at{BIG} NOT NULL ){SFX}
CREATE TABLE IF NOT EXISTS articles ( id{V32} PRIMARY KEY, author_id{V32} NOT NULL, category_id{V32} NOT NULL, title{V255} NOT NULL, slug{VK} NOT NULL UNIQUE, legacy_permalink{VLK} NOT NULL DEFAULT '', summary_md{TXT} NOT NULL, content_md{LTXT} NOT NULL, cover_url{V512} NOT NULL, status{V32} NOT NULL, published_at{BIG} NOT NULL DEFAULT 0, scheduled_at{BIG} NOT NULL DEFAULT 0, is_pinned{BOOL} NOT NULL DEFAULT {F}, allow_comment{BOOL} NOT NULL DEFAULT {T}, password_ciphertext{TXT} NOT NULL, has_content_lock{BOOL} NOT NULL DEFAULT {F}, audio_url{V512} NOT NULL, audio_duration_sec{INT} NOT NULL DEFAULT 0, audio_size_bytes{BIG} NOT NULL DEFAULT 0, audio_mime{V64} NOT NULL, lang{V32} NOT NULL, translation_group{V128} NOT NULL, license_override{TXT} NOT NULL, word_count{INT} NOT NULL DEFAULT 0, reading_minutes{INT} NOT NULL DEFAULT 0, view_count{BIG} NOT NULL DEFAULT 0, comment_count{INT} NOT NULL DEFAULT 0, created_at{BIG} NOT NULL, updated_at{BIG} NOT NULL ){SFX}
CREATE INDEX idx_articles_status_pub ON articles (status, is_pinned, published_at)
CREATE INDEX idx_articles_status_pub_at ON articles (status, published_at)
CREATE INDEX idx_articles_status_views_pub ON articles (status, view_count, published_at)
CREATE INDEX idx_articles_status_comments_pub ON articles (status, comment_count, published_at)
CREATE INDEX idx_articles_pinned_updated ON articles (is_pinned, updated_at)
CREATE INDEX idx_articles_status_pinned_updated ON articles (status, is_pinned, updated_at)
CREATE INDEX idx_articles_category ON articles (category_id, status, published_at)
CREATE INDEX idx_articles_author ON articles (author_id, status, updated_at)
CREATE INDEX idx_articles_legacy_link ON articles (legacy_permalink)
CREATE INDEX idx_articles_scheduled ON articles (status, scheduled_at)
CREATE INDEX idx_articles_trans_group ON articles (translation_group, lang)
CREATE TABLE IF NOT EXISTS article_tags ( article_id{V32} NOT NULL, tag_id{V32} NOT NULL, PRIMARY KEY (article_id, tag_id) ){SFX}
CREATE INDEX idx_article_tags_tag ON article_tags (tag_id)
CREATE TABLE IF NOT EXISTS article_revisions ( id{V32} PRIMARY KEY, article_id{V32} NOT NULL, title{V255} NOT NULL, summary_md{TXT} NOT NULL, content_md{LTXT} NOT NULL, author_name{V128} NOT NULL, note{V255} NOT NULL, created_at{BIG} NOT NULL ){SFX}
CREATE INDEX idx_article_revisions_art ON article_revisions (article_id, created_at)
CREATE TABLE IF NOT EXISTS article_backlinks ( source_article_id{V32} NOT NULL, target_article_id{V32} NOT NULL, updated_at{BIG} NOT NULL, PRIMARY KEY (source_article_id, target_article_id) ){SFX}
CREATE INDEX idx_article_backlinks_target ON article_backlinks (target_article_id, updated_at)
CREATE TABLE IF NOT EXISTS pages ( id{V32} PRIMARY KEY, author_id{V32} NOT NULL, title{V255} NOT NULL, slug{VK} NOT NULL UNIQUE, template{V64} NOT NULL DEFAULT 'default', content_md{LTXT} NOT NULL, is_published{BOOL} NOT NULL DEFAULT {T}, allow_comment{BOOL} NOT NULL DEFAULT {T}, show_toc{BOOL} NOT NULL DEFAULT {T}, lang{V32} NOT NULL, translation_group{V128} NOT NULL, view_count{BIG} NOT NULL DEFAULT 0, comment_count{INT} NOT NULL DEFAULT 0, created_at{BIG} NOT NULL, updated_at{BIG} NOT NULL ){SFX}
CREATE INDEX idx_pages_trans_group ON pages (translation_group, lang)
CREATE TABLE IF NOT EXISTS nav_items ( id{V32} PRIMARY KEY, parent_id{V32} NOT NULL, title{V128} NOT NULL, i18n_titles_json{TXT} NOT NULL, url{V512} NOT NULL, open_in_new_tab{BOOL} NOT NULL DEFAULT {F}, icon{V255} NOT NULL, sort_order{INT} NOT NULL DEFAULT 0, is_enabled{BOOL} NOT NULL DEFAULT {T}, created_at{BIG} NOT NULL, updated_at{BIG} NOT NULL ){SFX}
CREATE INDEX idx_nav_items_order ON nav_items (sort_order)
CREATE TABLE IF NOT EXISTS series ( id{V32} PRIMARY KEY, title{V255} NOT NULL, slug{VK} NOT NULL UNIQUE, description{TXT} NOT NULL, cover_url{V512} NOT NULL, sort_order{INT} NOT NULL DEFAULT 0, created_at{BIG} NOT NULL, updated_at{BIG} NOT NULL ){SFX}
CREATE TABLE IF NOT EXISTS series_articles ( series_id{V32} NOT NULL, article_id{V32} NOT NULL, sort_order{INT} NOT NULL DEFAULT 0, PRIMARY KEY (series_id, article_id) ){SFX}
CREATE INDEX idx_series_articles_art ON series_articles (article_id)
CREATE INDEX idx_series_articles_sort ON series_articles (series_id, sort_order)
CREATE TABLE IF NOT EXISTS books ( id{V32} PRIMARY KEY, title{V255} NOT NULL, slug{VK} NOT NULL UNIQUE, description{TXT} NOT NULL, cover_url{V512} NOT NULL, source_type{V32} NOT NULL, source_url{V512} NOT NULL, series_id{V32} NOT NULL, embed_mode{V32} NOT NULL, reading_status{V32} NOT NULL DEFAULT '', chapter_count{INT} NOT NULL DEFAULT 0, synced_at{BIG} NOT NULL DEFAULT 0, sort_order{INT} NOT NULL DEFAULT 0, created_at{BIG} NOT NULL, updated_at{BIG} NOT NULL ){SFX}
CREATE TABLE IF NOT EXISTS book_chapters ( id{V32} PRIMARY KEY, book_id{V32} NOT NULL, parent_id{V32} NOT NULL, title{V255} NOT NULL, url{V512} NOT NULL, depth{INT} NOT NULL DEFAULT 0, sort_order{INT} NOT NULL DEFAULT 0 ){SFX}
CREATE INDEX idx_book_chapters_book ON book_chapters (book_id, sort_order)
CREATE TABLE IF NOT EXISTS comments ( id{V32} PRIMARY KEY, target_type{V32} NOT NULL, target_id{V32} NOT NULL, parent_id{V32} NOT NULL, reply_to_name{V128} NOT NULL, user_id{V32} NOT NULL, guest_id_hash{V64} NOT NULL, env_fp_hash{V64} NOT NULL, author_name{V128} NOT NULL, author_url{V512} NOT NULL, avatar_url{V512} NOT NULL, notify_email_ciphertext{TXT} NOT NULL, notify_locale{V32} NOT NULL, client_ip{V64} NOT NULL, ip_masked{V64} NOT NULL, geo_region{V128} NOT NULL, content_md{TXT} NOT NULL, status{V32} NOT NULL, is_deleted{BOOL} NOT NULL DEFAULT {F}, created_at{BIG} NOT NULL, updated_at{BIG} NOT NULL ){SFX}
CREATE INDEX idx_comments_target_status ON comments (target_type, target_id, status, created_at)
CREATE INDEX idx_comments_target_del_created ON comments (target_type, target_id, is_deleted, created_at, id)
CREATE INDEX idx_comments_status_created ON comments (status, created_at)
CREATE INDEX idx_comments_del_status_created ON comments (is_deleted, status, created_at)
CREATE INDEX idx_comments_del_created ON comments (is_deleted, created_at)
CREATE INDEX idx_comments_guest ON comments (guest_id_hash)
CREATE INDEX idx_comments_user ON comments (user_id)
CREATE TABLE IF NOT EXISTS reactions ( target_type{V32} NOT NULL, target_id{V32} NOT NULL, actor_hash{V64} NOT NULL, kind{V32} NOT NULL, created_at{BIG} NOT NULL, PRIMARY KEY (target_type, target_id, actor_hash, kind) ){SFX}
CREATE TABLE IF NOT EXISTS links ( id{V32} PRIMARY KEY, title{V255} NOT NULL, url{V512} NOT NULL, description{TXT} NOT NULL, icon_url{V512} NOT NULL, category_name{V64} NOT NULL, sort_order{INT} NOT NULL DEFAULT 0, health_status{V32} NOT NULL, http_code{INT} NOT NULL DEFAULT 0, latency_ms{INT} NOT NULL DEFAULT 0, health_error{V255} NOT NULL, last_checked_at{BIG} NOT NULL DEFAULT 0, created_at{BIG} NOT NULL, updated_at{BIG} NOT NULL ){SFX}
CREATE INDEX idx_links_order ON links (sort_order)
CREATE TABLE IF NOT EXISTS follows ( id{V32} PRIMARY KEY, title{V255} NOT NULL, site_url{V512} NOT NULL, feed_url{V512} NOT NULL, description{TXT} NOT NULL, icon_url{V512} NOT NULL, sort_order{INT} NOT NULL DEFAULT 0, last_synced_at{BIG} NOT NULL DEFAULT 0, sync_error{V255} NOT NULL, created_at{BIG} NOT NULL, updated_at{BIG} NOT NULL ){SFX}
CREATE TABLE IF NOT EXISTS follow_items ( id{V32} PRIMARY KEY, follow_id{V32} NOT NULL, guid_hash{V64} NOT NULL, title{V255} NOT NULL, url{V512} NOT NULL, summary{TXT} NOT NULL, author_name{V128} NOT NULL, published_at{BIG} NOT NULL, UNIQUE (follow_id, guid_hash) ){SFX}
CREATE INDEX idx_follow_items_pub ON follow_items (published_at)
CREATE TABLE IF NOT EXISTS media_assets ( id{V32} PRIMARY KEY, storage_driver{V32} NOT NULL, object_key{VK} NOT NULL UNIQUE, public_url{V512} NOT NULL, original_name{V255} NOT NULL, alt_text{V512} NOT NULL DEFAULT '', mime_type{V64} NOT NULL, size_bytes{BIG} NOT NULL, width{INT} NOT NULL DEFAULT 0, height{INT} NOT NULL DEFAULT 0, sha256{V64} NOT NULL, exif_stripped{BOOL} NOT NULL DEFAULT {T}, uploader_id{V32} NOT NULL, created_at{BIG} NOT NULL ){SFX}
CREATE INDEX idx_media_assets_created ON media_assets (created_at)
CREATE TABLE IF NOT EXISTS redirects ( id{V32} PRIMARY KEY, source_path{VLK} NOT NULL DEFAULT '' UNIQUE, target_path{V512} NOT NULL, status_code{INT} NOT NULL DEFAULT 301, is_system_legacy{BOOL} NOT NULL DEFAULT {F}, hit_count{BIG} NOT NULL DEFAULT 0, created_at{BIG} NOT NULL ){SFX}
CREATE INDEX idx_redirects_created ON redirects (created_at)
CREATE TABLE IF NOT EXISTS webhooks ( id{V32} PRIMARY KEY, name{V128} NOT NULL, provider{V32} NOT NULL, url{V512} NOT NULL, secret_ciphertext{TXT} NOT NULL, chat_id{V128} NOT NULL, events_json{TXT} NOT NULL, is_enabled{BOOL} NOT NULL DEFAULT {T}, last_status_code{INT} NOT NULL DEFAULT 0, last_error{V255} NOT NULL, last_triggered_at{BIG} NOT NULL DEFAULT 0, created_at{BIG} NOT NULL, updated_at{BIG} NOT NULL ){SFX}
CREATE TABLE IF NOT EXISTS webhook_deliveries ( id{V32} PRIMARY KEY, webhook_id{V32} NOT NULL, event{V64} NOT NULL, status_code{INT} NOT NULL DEFAULT 0, duration_ms{INT} NOT NULL DEFAULT 0, success{BOOL} NOT NULL DEFAULT {F}, payload_json{TXT} NOT NULL, response_body{TXT} NOT NULL, error_text{V255} NOT NULL, created_at{BIG} NOT NULL ){SFX}
CREATE INDEX idx_webhook_deliveries_hook_created ON webhook_deliveries (webhook_id, created_at)
CREATE TABLE IF NOT EXISTS analytics_daily ( stat_date{V32} PRIMARY KEY, pv{BIG} NOT NULL DEFAULT 0, uv{BIG} NOT NULL DEFAULT 0, updated_at{BIG} NOT NULL ){SFX}
CREATE TABLE IF NOT EXISTS analytics_top_items ( stat_date{V32} NOT NULL, kind{V32} NOT NULL, item_key{VLK} NOT NULL DEFAULT '', hits{BIG} NOT NULL DEFAULT 0, PRIMARY KEY (stat_date, kind, item_key) ){SFX}
CREATE TABLE IF NOT EXISTS security_ip_bans ( id{V32} PRIMARY KEY, cidr{V64} NOT NULL UNIQUE, source{V32} NOT NULL, reason_code{V64} NOT NULL, reason{TXT} NOT NULL, note{TXT} NOT NULL, occurrences{INT} NOT NULL DEFAULT 1, expires_at{BIG} NOT NULL DEFAULT 0, created_at{BIG} NOT NULL, updated_at{BIG} NOT NULL ){SFX}
CREATE TABLE IF NOT EXISTS security_geo_rules ( id{V32} PRIMARY KEY, name{V128} NOT NULL, is_enabled{BOOL} NOT NULL DEFAULT {T}, action{V32} NOT NULL, on_miss{V32} NOT NULL, countries{TXT} NOT NULL, regions{TXT} NOT NULL, sort_order{INT} NOT NULL DEFAULT 0, created_at{BIG} NOT NULL, updated_at{BIG} NOT NULL ){SFX}
CREATE INDEX idx_security_geo_rules_order ON security_geo_rules (sort_order)
CREATE TABLE IF NOT EXISTS audit_logs ( id{V32} PRIMARY KEY, actor_id{V32} NOT NULL, actor_name{V128} NOT NULL, action{V64} NOT NULL, resource_type{V64} NOT NULL, resource_id{V64} NOT NULL, client_ip{V64} NOT NULL, detail_json{TXT} NOT NULL, created_at{BIG} NOT NULL ){SFX}
CREATE INDEX idx_audit_logs_created ON audit_logs (created_at)
CREATE TABLE IF NOT EXISTS plugins ( id{V64} PRIMARY KEY, kind{V32} NOT NULL, version{V32} NOT NULL, is_enabled{BOOL} NOT NULL DEFAULT {F}, config_json{TXT} NOT NULL, secret_ciphertext{TXT} NOT NULL, circuit_state{V32} NOT NULL, failure_count{INT} NOT NULL DEFAULT 0, last_error{TXT} NOT NULL, installed_at{BIG} NOT NULL, updated_at{BIG} NOT NULL ){SFX}
CREATE TABLE IF NOT EXISTS plugin_kv ( plugin_id{V64} NOT NULL, k{VK} NOT NULL, value_text{LTXT} NOT NULL, value_int{BIG} NOT NULL DEFAULT 0, expires_at{BIG} NOT NULL DEFAULT 0, updated_at{BIG} NOT NULL, PRIMARY KEY (plugin_id, k) ){SFX}
CREATE INDEX idx_plugin_kv_exp ON plugin_kv (expires_at)